package com.hafiz.application1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.hafiz.application1.data.DBHelper;

public class DeleteActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delete);

        DBHelper db = new DBHelper(DeleteActivity.this);

    }

    public void onClickDelete(View view){
        DBHelper db = new DBHelper(DeleteActivity.this);
        EditText EditTextDelete1 = findViewById(R.id.EditTextDelete1);
        int res = db.deleteStudent(Integer.parseInt(EditTextDelete1.getText().toString()));
        if(res > 0){
            Context context = getApplicationContext();
            CharSequence text = "Record Deleted successfully.";
            int duration = Toast.LENGTH_SHORT;
            Toast toast = Toast.makeText(context, text, duration);
            toast.show();
        }else{
            Context context = getApplicationContext();
            CharSequence text = "Error: Record not found.";
            int duration = Toast.LENGTH_SHORT;
            Toast toast = Toast.makeText(context, text, duration);
            toast.show();
        }

    }
}