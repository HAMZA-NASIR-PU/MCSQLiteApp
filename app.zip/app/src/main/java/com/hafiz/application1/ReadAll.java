package com.hafiz.application1;

import androidx.appcompat.app.AppCompatActivity;
import com.hafiz.application1.model.StudentModel;
import com.hafiz.application1.data.DBHelper;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class ReadAll extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_read_all);


        DBHelper db = new DBHelper(ReadAll.this);
        ListView listView = findViewById(R.id.listView);
        ArrayList<String> students = new ArrayList<>();

        List<String> allStudents = db.getAllStudents();

        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, allStudents);
        listView.setAdapter(arrayAdapter);
    }
}