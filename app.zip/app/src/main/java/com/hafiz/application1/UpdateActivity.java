package com.hafiz.application1;

import androidx.appcompat.app.AppCompatActivity;
import com.hafiz.application1.data.DBHelper;
import com.hafiz.application1.model.StudentModel;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class UpdateActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update);
    }

    public void onClickUpdate(View view){
        DBHelper db = new DBHelper(UpdateActivity.this);
        EditText UpdateEditText1 = findViewById(R.id.UpdateEditText1);
        EditText UpdateEditText2 = findViewById(R.id.UpdateEditText2);
        EditText UpdateEditText3 = findViewById(R.id.UpdateEditText3);
        int res = db.updateStudent(Integer.parseInt(UpdateEditText1.getText().toString()), new StudentModel(UpdateEditText2.getText().toString(),
                Integer.parseInt(UpdateEditText3.getText().toString())));
        if(res > 0){
            Context context = getApplicationContext();
            CharSequence text = UpdateEditText3.getText().toString() + " updated successfully.";
            int duration = Toast.LENGTH_SHORT;
            Toast toast = Toast.makeText(context, text, duration);
            toast.show();
        }else{
            Context context = getApplicationContext();
            CharSequence text = "Error: Record not found.";
            int duration = Toast.LENGTH_SHORT;
            Toast toast = Toast.makeText(context, text, duration);
            toast.show();
        }
    }
}