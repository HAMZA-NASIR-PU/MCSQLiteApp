package com.hafiz.application1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;
import com.hafiz.application1.data.DBHelper;
import com.hafiz.application1.model.StudentModel;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    Button insertBtn, readAllBtn;
    EditText editText1, editText2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        insertBtn = findViewById(R.id.insertBtn);
        readAllBtn = findViewById(R.id.readAllBtn);
        editText1 = findViewById(R.id.editText1);
        editText2 = findViewById(R.id.editText2);

        insertBtn.setOnClickListener(new View.OnClickListener() {
            StudentModel studentModel;

            @Override
            public void onClick(View v) {
                try {
                    studentModel = new StudentModel(editText1.getText().toString(), Integer.parseInt(editText2.getText().toString()));
                    DBHelper dbHelper  = new DBHelper(MainActivity.this);
                    dbHelper.addStudent(studentModel);
                    Context context = getApplicationContext();
                    CharSequence text = editText2.getText().toString() + " added successfully.";
                    int duration = Toast.LENGTH_SHORT;
                    Toast toast = Toast.makeText(context, text, duration);
                    toast.show();
                    Log.d("dbhamza", "Inserted");

                }
                catch (Exception e){
                    Toast.makeText(MainActivity.this, "Error", Toast.LENGTH_SHORT).show();
                }

            }
        });
    }


    public void readAll(View view){
        Intent intent =new Intent(this,ReadAll.class);
        startActivity(intent);
    }

    public void updateData(View view){
        Intent intent =new Intent(this,UpdateActivity.class);
        startActivity(intent);
    }

    public void deleteData(View view){
        Intent intent =new Intent(this,DeleteActivity.class);
        startActivity(intent);
    }
}